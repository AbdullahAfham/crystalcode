<?php 
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "nav-item active";

include('header.php');?>

	<!-- Home Page Banner Area Start -->
	<section id="banner" class="breadcrumb">
		<div class="container">
			<div class="row">
				<div class="banner-info">
					<div class="col-12">
						<span>Think Big & Get Rewards</span>
						<h1>Browse Hyip </h1>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Home Page Banner Area End -->

	<!-- brows hyip Area Start -->
	<section id="browshyip">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="bh_tabs">
						<nav>
							<div class="nav nav-tabs" id="nav-tab" role="tablist">
								<a class="nav-item nav-link active" id="nav-active-tab" data-toggle="tab" href="#nav-active" role="tab"
								 aria-controls="nav-active" aria-selected="true">Finished</a>
								<a class="nav-item nav-link" id="nav-scam-tab" data-toggle="tab" href="#nav-scam" role="tab" aria-controls="nav-scam"
								 aria-selected="false">Ongoing</a>
								<a class="nav-item nav-link" id="nav-pending-tab" data-toggle="tab" href="#nav-pending" role="tab"
								 aria-controls="nav-pending" aria-selected="false">pending</a>
							</div>
						</nav>
						<div class="tab-content" id="nav-tabContent">
							<div class="tab-pane fade show active" id="nav-active" role="tabpanel" aria-labelledby="nav-active-tab">
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="nav-scam" role="tabpanel" aria-labelledby="nav-scam-tab">
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="nav-pending" role="tabpanel" aria-labelledby="nav-pending-tab">
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<div class="bodyArea">
											<div class="row">
												<div class="col-lg-6">
													<div class="content d-flex">
														<div class="left">
															<img src="img/browse_hyip.png" alt="">
														</div>
														<div class="right">
															<h2>Instant Bitex Ltd</h2>
															<ul>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Details
																		<a href="#">
																			(Rate now)
																		</a>
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Forum
																	</p>
																</li>
																<li>
																	<p>
																		<i class="fas fa-caret-right"></i>
																		Program Features
																	</p>
																</li>
															</ul>
														</div>
													</div>
												</div>
												<div class="col-lg-6">
													<div class="row content2">
														<div class="col-md-6 left">
															<a href="#">
																Paying Instantly
															</a>
															<ul>
																<li>
																	<p>
																		<strong>
																			Payouts:
																		</strong>
																		2.1-5% daily!
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Min deposit:
																		</strong>
																		$10
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			PMax deposit:
																		</strong>
																		$50,000
																	</p>
																</li>
																<li>
																	<p>
																		<strong>
																			Referral bonus:
																		</strong>
																		1%
																	</p>
																</li>
															</ul>
														</div>
														<div class="col-md-6 right d-flex align-self-center">
															<div class="right_img">
																<img class="img-fluid" src="img/browse_hyip2.png" alt="">
																<img class="img-fluid" src="img/browse_hyip3.png" alt="">
															</div>
														</div>
													</div>
												</div>
											</div>

										</div>
										<div class="bottom_area d-flex justify-content-between">
											<p>Lifetime: 83 Days</p>
											<p>Monitoring: 43 days</p>
											<p>Admin rate: 1</p>
											<p>User rate: 43.0 </p>
											<p>Funds return: 101.00% </p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- brows hyip Area End -->

<?php include('footer.php');?>