$(function ($) {
    "use strict"

    // counter js

    $('.count').counterUp({
        delay: 10,
        time: 2000
    });


});

